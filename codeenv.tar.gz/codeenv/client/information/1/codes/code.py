x = int(input())
while x<24:
	if x==1:
		print(p)
print("Hello World. The number id "+str(x)+".")
