#include<stdio.h>

int main() {
	int x;
	scanf("%d", &x);
	printf("Hello World. The number id %d.\n", x);
}
