#include<iostream>

using namespace std;

int main() {
	int x;
	cin>>x;
	cout<<"Hello World. The number id "<<x<<endl;
}
